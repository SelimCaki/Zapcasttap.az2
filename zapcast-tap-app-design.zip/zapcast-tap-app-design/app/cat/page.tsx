import type { Metadata } from 'next'
import { ChatScreen } from '@/components/chat/chat-screen'

export const metadata: Metadata = { title: 'Çat — ZapçastTap' }

export default function ChatPage() {
  return (
    <main className="flex flex-1 flex-col">
      <ChatScreen />
    </main>
  )
}
