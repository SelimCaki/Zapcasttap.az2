import type { Metadata } from 'next'
import Image from 'next/image'
import { Clock } from 'lucide-react'
import { BottomNav } from '@/components/bottom-nav'
import { OffersList } from '@/components/offers/offers-list'
import { ScreenHeader } from '@/components/screen-header'
import { activeRequest, offers } from '@/lib/data'

export const metadata: Metadata = { title: 'Təkliflər və Qiymətlər — ZapçastTap' }

export default function OffersPage() {
  return (
    <>
      <main className="flex flex-1 flex-col gap-5 pb-6">
        <div className="bg-brand pb-5">
          <ScreenHeader title="Təkliflər və Qiymətlər" />
          <section
            aria-label="Aktiv sorğu"
            className="mx-4 flex items-center gap-3 rounded-2xl bg-white/5 p-3 ring-1 ring-white/10"
          >
            <Image
              src="/images/bumper.png"
              alt="Qabaq bamper"
              width={64}
              height={64}
              className="size-16 rounded-xl object-cover"
            />
            <div className="min-w-0 flex-1">
              <p className="text-xs text-slate-400">Aktiv sorğunuz</p>
              <h2 className="text-sm font-bold leading-snug text-white text-pretty">
                {activeRequest.title}
              </h2>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <span className="flex items-center gap-1.5 rounded-full bg-highlight px-2.5 py-1 text-[11px] font-bold text-highlight-foreground">
                  <span className="size-1.5 animate-pulse rounded-full bg-highlight-foreground" aria-hidden="true" />
                  Aktiv ({offers.length} Təklif)
                </span>
                <span className="flex items-center gap-1 text-[11px] text-slate-400">
                  <Clock className="size-3" aria-hidden="true" />
                  {activeRequest.createdAt}
                </span>
              </div>
            </div>
          </section>
        </div>
        <OffersList />
      </main>
      <BottomNav />
    </>
  )
}
